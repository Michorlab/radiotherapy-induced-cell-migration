#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include "string.h"
#include "math.h"
#include "time.h"


double randZerotoOne()
{
    double temp = rand();
    double t1 = temp / (double) RAND_MAX;
    //double t1 = ((double) rand() / (RAND_MAX));
    return t1;
}

double lognormal_rand(double mean, double var) {
    // INTPUT ARGUMENTS ARE THE NORMAL DISTRIBUTION'S MEAN AND VARIANCE
    double mu = log(mean);
    double sig = sqrt(log(1+var/(mean*mean)));
    
    double u1 = rand() / (double)RAND_MAX; // Uniform random variable between 0 and 1
    double u2 = rand() / (double)RAND_MAX; // Uniform random variable between 0 and 1
    
    // Box-Muller transform to generate standard normal random variables
    double z0 = sqrt(-2 * log(u1)) * cos(2 * M_PI * u2);
    // Convert standard normal random variable to log-normal
    double log_normal = exp(mu + sig * z0);
    
    return log_normal;
}


//Returns approximate value of e^x using sum of first n terms of Taylor Series
float exponential(int n, float x)
{
    float sum = 1.0f; // initialize sum of series
    int i;
    for (i = n - 1; i > 0; --i )
        sum = 1 + x * sum / i;

    return sum;
}

//Returns a force factor derived from the Lennard-Jones potential
double forceFact_fun(double energy_scale, double length_scale, double dist_sq){
    double res;
    res = energy_scale*(1/dist_sq)*(pow(length_scale*length_scale/dist_sq,6)-0.5*pow(length_scale*length_scale/dist_sq,3));
    return res;
    
}

//void cellMobilityModelLoop(int maxTimeSteps, double sens, int Z, int Zrevert, int ChemoWeeks, int ChemoDays, int ChemoDoses, int ThalfPerDose[7], int ChemoDay[7], int ChemoHour[7], double Cmax, int RadWeeks, int radDoses, int radDoseA[10], int radHour[10], int radDay[10], int *stemCount, int * tbCount, int * escCount, int *cellAge, double * cellsX, double * cellsY, double * cellRadii, int * numCells_out)
void cellMobilityModelLoop(int maxTimeSteps, double sens, int Z, int Zrevert,int RadWeeks, int radDoses, int radDoseA[100], int radHour[100], int radDay[100], int *stemCount, int * tbCount, int * escCount, int *cellAge, double * cellsX, double * cellsY, double * cellRadii,double * cellsX_preTreat,double * cellsY_preTreat,double * cellRadii_preTreat, int* preTreat_numCells, int* postTreat_numCells, double * tumorDensities,double * tumorMaxRadii, double* rad_cen_x_out, double* rad_cen_y_out, double* IR_radius_out, int * cellState, int job_id)
{
    
    int rank;
    int radDose;
    int typeCounter;
    double maxDist;

    srand(1); /* initialize rand(), hardcoded for validation. Change to driven from the time step for full data collection. */
    /**PARAMETER VALUES **/
    //BINARY VARIABLES FOR MODLEING CHOICES
    int rand_treatment = 1; // if rand vars in treatment simulations have different seeds
    int Quiescence = 1; //if model includes quiescent state after IR
    int fixRadRegion = 1; //if IR region(radius) is kept fixed throughout RT
    int cellGrowth_pretreat = 0; //if cell growth is included in pretreatment simulation
    int cellGrowth_treat = 0; // if cell growth is included in treatment simulation
    
    double rTB = .0038; // 0.0038 from Cell paper, proliferation rate of tumor cells after exiting quiescence ?
    
    // MODEL SETUP PARAMETERS
    int initialCellCount = 500; //initial cell count before pretreatment simulation
    int numCells = initialCellCount; //pretreatment tumor cell count is around 6*initCellCount
    int DT = 2; //time steps per minute
    int T_fast_cycle = 0;// cells division time = lambda_fast_cycle (2 minutes) (fast proliferation)
    int lambda_fast_cycle = 1000000; //fast cell division time in pretreatment simulation
    int therapyStart = DT*60; // changed from 2800

    
    
    //TUMOR MORPHOLOGY PARAMETERS
    int R=2; //radius of tumor cells
    double Rcell = 2.0; //radius of tumor cells
    //int doublingTime = 119; //doubling time (hours)
    //double kg = log(2)/doublingTime;
    
    double kg = 0.14/24; //NSLC tumor growth rate, from Baaz et al. 2023
    double lambda = 1/kg*(DT*60);
    //double lambda = doublingTime*(DT*60);  //average cell cycle time
    double lambda_var = pow(2*lambda,2);
//    double log_lambda = log(lambda*lambda/sqrt(lambda_var+lambda*lambda));
//    double log_lambda_var = sqrt(log(lambda_var/(lambda*lambda)+1));
    
    double kd = 0.09/24; ///NSLC tumor death rate, from Baaz et al. 2023
    double randomDeathProb= (1/kd)*(DT*60);//2*24*60*2;
    double growth = 1.0057; //growth rate of tumor cell size
    
    
    //CELL MOTIONS
    double energy_scale = 0.2; //how cell movement scales with interaction energy
    double length_scale;
    double cell_mem_rigidity = 0.9;
    double dose_speed_fact =1;
    double dose_speed_corr = 0.0;
    double BM_scale_pretreat = 0.04;
    double BM_scale_treat = 0.02;
    double IR_tumor_ratio = 1000;//1.1;
    double max_IR_tumor_ratio = 1000; //for when IR region isn't fixed: used value = 1.1
    double max_IR_radius;
    
    
    //RT RELATED PARAMETERS
    double LTumorBulk = 0; //24; min. number of hours for cells in quiescence
    double lambdaTumorBulk =1; //.1; rate of cells exising quiescience
    
    double alpha; // .00987;
    double alphaT =.2432; //old value: .0987; radiosensitive value .12
    double beta;
    double betaT = 0.0257;
    double rho = 1;


    
    
    
    

    //char XYZname[35];
    //int ratioTbtoS = 20; //ratio of tumor bulk to stem cells before therapy
    //double tmp;
    //int tau = 3; //number of cell diameters away from vessel wall that stem cells can exit
    //double growthRate = .0004;
    //int k = 5000; //spring constant
    //double rS = .0008; //from Cell paper, proliferation rate of stem cells after exiting quiescence
    
    // ADDITIONAL PARAMETERS/VARIABLES
    

    
    
    //int timeDepGamma = 0;
    //double mu = 3.25*DT*60;
    //double sigmaS = 1.46*DT*DT*60*60;

//    double alpha, alphaS; // .00987;
//    double alphaT =.2432; //old value: .0987; radiosensitive value .12
//    double beta, betaS;
//    double betaT = 0.0257;
//    double gamma = .4;
//    double RadRho = .4;
//    double LStem = 36;
//    //double LTumorBulk = 0; //24; min. number of hours for cells in quiescence
//    double lambdaStem = .0328;
//    //double lambdaTumorBulk =1; //.1; rate of cells exising quiescience
//    double mTumorBulk = 24*(DT*60);
//    double nuTumorBulk = .54;

    int giveRad = 0;
    int RAD_KILL=0;
 //   int Ch_rm=0;
    int TOT_RAD=0;
    int TOT_DIV = 0;
    int TOT_KILL = 0;

    double ct1= 1;
    double dt2 = ct1/((double) DT) * ct1/((double) DT);
    int T = 1;


    for (T=0; T < maxTimeSteps; T++) {
        tbCount[T] = 0;
        stemCount[T] = 0;
    }
    
    // FOR TRACKING TUMOR CENTER
    double tumor_cen_x = 0.0;
    double tumor_cen_y = 0.0;
    double rad_cen_x = 0.0;
    double rad_cen_y = 0.0;
    double IR_radius = 10000;
    double tumor_radius = -1.0;
    double max_pos_x = -1.0;
    double max_pos_y = -1.0;
    double max_neg_x = 1.0;
    double max_neg_y = 1.0;
    double cellDist2RadCen;
    int curr_rad_time = maxTimeSteps+1;
    double dimEffect = 1;
    int dimEffectYN[100];
    double incdSpeed[100];
    int doseExpTime[100];
    int radNum = 0;
    

    //int simTime = 0; //time elapsed in simulation time, ie DT*T

    //double cellRadii[10000];
    //double cellsX[10000];
    //double cellsY[10000];
    
    double forcesX[10000];
    double forcesY[10000];
    int cellQ[10000];
    int cellDivTime[10000];
    double cellConc[10000];
    int cellDivRate[10000];
    int cellDeathTime[10000];
    double cellDist[10000];
    int radQ[10000];
    int radQt[10000];
    
    //MOD: cellState keeps track of normal, dead, and quiescent cells
    // states: 0 = normal, 1 = dead, 2 = quiescent
    //int cellState[10000];
    
    int i, j;
    
    //int numCells = floor( 3.14*2*(Rvessel+2*R)/(2*R));

    int max_cycles=1;
    int cycle;
    for (cycle = 0; cycle < max_cycles; cycle++) {
        for (i=0; i < 10000; i++)
        {
            cellRadii[i] = R;
            cellsX[i] = 0;
            forcesX[i] = 0;
            cellsY[i] = 0;
            forcesY[i] = 0;
            cellQ[i] = 0;
            cellConc[i] = 0;
            cellDivTime[i] = 10000*2;
            cellDeathTime[i] = 10000*2;
            cellDivRate[i] = 0;
            cellDist[i] = 0;
            cellAge[i] = 0;
            radQ[i] = 0;
            radQt[i] = 0;
            // MOD: INITIALIZE CELL STATES: ALL CELLS ARE NORMAL
            cellState[i] = 0;
        }
        /*INITIALIZING INITIAL POSITIONS OF TUMOR CELLS*/
        cellsX[0] = 0;
        cellsY[0] = 0;
        
        int cellsLeft = initialCellCount -1; // tumor cells left for position assignment
        int counter = 1;
        int ringNum = 1; // current layer number layer 0 is the center cell at origin
        double compactness = 0.1;
        
        while (cellsLeft > 0){
            double radiusRing = compactness*Rcell + (2+compactness)*ringNum*Rcell;
            int cellNumRing = (int) floor(3.14*2*radiusRing/(2*Rcell));
            if (cellNumRing > cellsLeft) {
                cellNumRing = cellsLeft;
            }
            for (j=0; j<cellNumRing; j++) {
                cellsX[counter] = radiusRing*cos(2*3.14/cellNumRing*j);
                cellsY[counter] = radiusRing*sin(2*3.14/cellNumRing*j);
                counter++;
            }
            ringNum++;
            cellsLeft = cellsLeft - cellNumRing;
        }
        int countDiv=0, countDeath=0;
        for (i=0; i < numCells; i++){
            //NO CELL DEATH AND DIVISION IN PRETREATMENT SIMULATION
            
            //cellDivTime[i] = (int) floor(randZerotoOne()); //(lambda));
            cellConc[i] = 0;
            //cellDeathTime[i] = (int) floor(randZerotoOne() * (randomDeathProb));
            cellDivRate[i] = (1/rTB)*DT*60;
            cellAge[i] = cellDeathTime[i];
            cellDist[i] = sqrt(cellsX[i]*cellsX[i] + cellsY[i] * cellsY[i]);
            //stemCount[0] = stemCount[0] + 1;
            tbCount[0] = tbCount[0] + 1;
            if (cellDeathTime[i] < cellDivTime[i]) countDeath ++;
            else countDiv++;
        }
        
        /*CALCULATE FORCE ON CELL AND MOVE TUMOR CELLS APPROPRIATELY*/
        double forceFact,invPdist2, pdistX,pdistY,pdist2, pdist1, pdist;
        int counter1,counter2;
        for (counter1 = 0; counter1 < numCells -1; counter1++) {
            for (counter2 = counter1+1; counter2 < numCells; counter2++) {
                //Calculate particle-particle distance
                pdistX = cellsX[counter1] - cellsX[counter2];
                pdistY = cellsY[counter1] - cellsY[counter2];

                //Calculate distance squared
                //pdist2 = pdistX*pdistX + pdistY*pdistY;

                //Calculate Lennard-Jones potential assuming sigma=1 and epsilon=1
                //See http://www.cchem.berkeley.edu/chem195/_l_j___force_8m.html#af8855bc03346959adac398ca74c45a06
                //for details.
//                //MODIFIED VERSION: TAKE INTERACTING CELLS' RADII INTO CONSIDERATION
//                pdist = sqrt(pdistX*pdistX + pdistY*pdistY) - 0.7*(cellRadii[counter1]+cellRadii[counter2]);
//                if (pdist<0.001) pdist=0.001;
//                pdist2 = pdist*pdist;
//                invPdist2 = 1/pdist2;
//                //forceFact = pow(invPdist2,4) * (pow(invPdist2,3)-0.5);
//                forceFact = 0.2*pow(invPdist2,3) * (pow(invPdist2,3)-1);
                
                //MODIFIED VERSION 2: INTERACTION FORCE FORM LJ POTENTIAL
                pdist = sqrt(pdistX*pdistX + pdistY*pdistY);
                if (pdist<0.001) pdist=0.001;
                pdist2 = pdist*pdist;
                length_scale = cell_mem_rigidity*(cellRadii[counter1]+cellRadii[counter2]);
                forceFact = forceFact_fun(energy_scale, length_scale, pdist2);

                //Calculate the action and reaction for the two particles
                forcesX[counter1] = forcesX[counter1] - pdistX * forceFact;
                forcesY[counter1] = forcesY[counter1] - pdistY * forceFact;
                forcesX[counter2] = forcesX[counter2] + pdistX * forceFact;
                forcesY[counter2] = forcesY[counter2] + pdistY * forceFact;
            }
        }
        //UPDATE CELL COORDINATES
        max_pos_x = -1.0;
        max_pos_y = -1.0;
        max_neg_x = 1.0;
        max_neg_y = 1.0;
        for (counter1 = 0; counter1 < numCells; counter1++) {
            if (forcesX[counter1] > .2) forcesX[counter1] = .2;
            else if (forcesX[counter1] < -.2) forcesX[counter1] = -.2;
            if (forcesY[counter1] > .2) forcesY[counter1] = .2;
            else if (forcesY[counter1] < -.2) forcesY[counter1] = -.2;
            cellsX[counter1] = cellsX[counter1]  - 0.5*dt2* 48 *forcesX[counter1];
            cellsY[counter1] = cellsY[counter1]  - 0.5*dt2* 48 *forcesY[counter1];
            forcesX[counter1] = 0;
            forcesY[counter1] = 0;
            cellDist[counter1] = sqrt((cellsX[counter1]-tumor_cen_x)*(cellsX[counter1]-tumor_cen_x)+ (cellsY[counter1]-tumor_cen_y)* (cellsY[counter1]-tumor_cen_y));
            //printf("%lf %lf \n",cellsY[counter1],cellsY[counter1]);
        }
        
        /*SIMULATION BEFORE TREAETMENT STARTS*/
        int day = 0; //day of the week in simulation
        int day_adjusted;
        int week = 0; //week in simulation
        int hour = 0; //hour in simulation
        int minute = 0; //minute in simulation
        
        double daughterCellSize;
        if (cellGrowth_pretreat == 1){
            daughterCellSize = 0.5;
        }
        else{
            daughterCellSize = 1;
        }
        
        
        for (T=0; T < therapyStart; T++) {//pre-treatment loop
            //printf("numCells = %d\n",numCells);
            /*****Handle Cell Death******/
            int numKillCells = 0;
            int * cellsToKill;
            double t1,t2;
            cellsToKill = (int *) malloc(sizeof(int)*50000);
            for (i=0; i< numCells; i++)//CELL DEATH
            {
                cellAge[i] = cellAge[i] +1;
                if (cellDeathTime[i] == 0)
                {
                    cellsToKill[numKillCells] = i;
                    numKillCells = numKillCells + 1;
                    TOT_KILL = TOT_KILL + 1;
                }

            }
            stemCount[T] = 0;
            tbCount[T] = 0;
            for (i=0; i < numCells; i++) {
                tbCount[T] = tbCount[T] + 1;
            }

//            for (i=0; i < numCells; i++) {
//                if (cellType[i] == 0) {
//                    stemCount[T] = stemCount[T] + 1;
//                }
//                else {
//                    tbCount[T] = tbCount[T] + 1;
//                }
//            }
             if (numKillCells > 0) {
                 for (i=0; i<numKillCells; i++) {
                    for (j=cellsToKill[i]; j<numCells-i-1; j++) {
                        cellsX[j] = cellsX[1+j];
                        cellsY[j] = cellsY[1+j];
                        cellDivTime[j] = cellDivTime[1+j];
                        cellConc[j] = cellConc[1+j];
                        cellDeathTime[j] = cellDeathTime[1+j];
                        cellDist[j] = cellDist[1+j];
                        cellAge[j] = cellAge[1+j];
                        cellDivRate[j] = cellDivRate[1+j];
                        cellQ[j] = cellQ[1+j];
                        radQ[j] = radQ[1+j];
                        radQt[j] = radQt[1+j];
                        cellRadii[j] = cellRadii[1+j];
                    }
                    cellsX[numCells] = 0;
                    cellsY[numCells] = 0;
                    cellDeathTime[numCells] = -1;
                    cellDivTime[numCells] = -1;
                    cellConc[numCells] = 0;
                    cellDist[numCells] = 0;
                    cellAge[numCells] = -1;
                    cellDivRate[numCells] = 0;
                    cellQ[numCells] = 0;
                    cellRadii[numCells] = 0;
                    radQ[numCells] = 0;
                    radQt[numCells] = 0;
                    numCells = numCells -1;
                }
            }
            free(cellsToKill);
            /*****Handle Cell Division******/
            //Given a Poisson distribution function determining the likelihood of cell division, calculate cell division
            for (i=0; i < numCells; i++) {
                //MOD: no cell division or cell die here
//                if (cellGrowth_pretreat == 1){
//                    if (cellRadii[i] < R*.1) cellDivTime[i] = (int) floor( randZerotoOne() * (lambda));
//                }
                
                //if (T<T_fast_cycle) cellDivTime[i] = (int) floor( randZerotoOne() * lambda_fast_cycle);
                if (cellDivTime[i] == 0)  {
                    if (cellQ[i] == 0) {
                        TOT_DIV = TOT_DIV + 1;
                        cellRadii[numCells] = daughterCellSize*cellRadii[i];
                        cellRadii[i] = cellRadii[i] *daughterCellSize;
                        double rtmp = randZerotoOne();
                        if (rtmp < .25) { //put horizontal
                            cellsX[numCells] = cellsX[i] + cellRadii[i];
                            cellsY[numCells] = cellsY[i];
                            cellsX[i] = cellsX[i] - cellRadii[i];
                            //printf("%lf %lf \n",cellsX[numCells],cellRadii[i]);
                        }
                        else if (rtmp < 0.5) { //put vertical
                            cellsY[numCells] = cellsY[i] + cellRadii[i];
                            cellsX[numCells] = cellsX[i];
                            cellsY[i] = cellsY[i] - cellRadii[i];
                            //printf("%lf %lf %lf \n",cellsX[i],cellsY[i],cellRadii[i]);
                        }
                        else if (rtmp < 0.75) { //diagonal
                            double h1 = sqrt(cellRadii[i] * cellRadii[i]*daughterCellSize);
                            cellsX[numCells] = cellsX[i] + h1;
                            cellsX[i] = cellsX[i] -h1 ;
                            cellsY[numCells] = cellsY[i]+h1;
                            cellsY[i] = cellsY[i] -h1;
                            //printf("%lf %lf %lf \n",cellsX[i],cellsY[i],h1);
                        }
                        else {
                            double h1 = sqrt(cellRadii[i] * cellRadii[i]*daughterCellSize);
                            cellsX[numCells] = cellsX[i] - h1;
                            cellsX[i] = cellsX[i] + h1 ;
                            cellsY[numCells] = cellsY[i] + h1;
                            cellsY[i] = cellsY[i] - h1;
                            //printf("%lf %lf %lf \n",cellsX[i],cellsY[i],h1);
                        }
                        cellDivRate[i] = (1/rTB)*DT*60;
                        //if (cellType[i] == 0) cellDivRate[i] = (1/rS)*DT*60;
                        //else cellDivRate[i] = (1/rTB)*DT*60;
                        cellDivRate[numCells] = cellDivRate[i];
                        cellConc[numCells] = cellConc[i];
                        cellDivTime[i] = (int) floor( randZerotoOne() * lambda);
                        cellDivTime[numCells] = (int) floor( randZerotoOne() * lambda);
                        cellDeathTime[i] = (int) floor( randZerotoOne() * (randomDeathProb));
                        cellAge[i]  = cellDeathTime[i];
                        cellDeathTime[numCells] = (int) floor( randZerotoOne() * (randomDeathProb));;
                        cellAge[numCells]  = cellDeathTime[numCells];
                        cellDist[i] = sqrt((cellsX[i]-tumor_cen_x)*(cellsX[i]-tumor_cen_x)+ (cellsY[i]-tumor_cen_y) * (cellsY[i]-tumor_cen_y));
                        //printf("%lf %lf %lf \n",cellsX[i],cellsY[i],cellDist[i]);
                        cellDist[numCells] = sqrt((cellsX[numCells]-tumor_cen_x)*(cellsX[numCells]-tumor_cen_x)+ (cellsY[numCells]-tumor_cen_y) * (cellsY[numCells]-tumor_cen_y));
                        cellQ[i] = 0;
                        cellQ[numCells] = 0;
                        radQ[i] = 0;
                        radQt[i] = 0;
                        radQ[numCells] = 0;
                        radQt[numCells] = 0;
                        numCells = numCells + 1;
                    }
                }
            }

            /*****Handle Cell Growth******/
            if (cellGrowth_pretreat == 1){
                for (i=0; i < numCells; i++) {
                    if (cellRadii[i] <= R*1.25) {
                        cellRadii[i] = cellRadii[i] * growth;
                        //printf("%lf \n",cellRadii[i] ); // values remian finite
                    }
                }
            }
            
            /*****Calculate Force on cell and move glial cells appropriately******/
            double forceFact,invPdist2, pdistX,pdistY,pdist2, pdist1, pdist;

            for (counter1 = 0; counter1 < numCells -1; counter1++) {
                for (counter2 = counter1+1; counter2 < numCells; counter2++) {
                    //Calculate particle-particle distance
                    pdistX = cellsX[counter1] - cellsX[counter2];
                    pdistY = cellsY[counter1] - cellsY[counter2];
                    
                    //Calculate Lennard-Jones potential assuming sigma=1 and epsilon=1
                    //See http://www.cchem.berkeley.edu/chem195/_l_j___force_8m.html#af8855bc03346959adac398ca74c45a06
                    //for details.
                    
                    //OLD VERSION:
                    
                    //Calculate distance squared
//                    pdist2 = pdistX*pdistX + pdistY*pdistY;
//                    invPdist2 = 1/pdist2;
//                    forceFact = pow(invPdist2,4) * (pow(invPdist2,3)-0.5);
                    //printf("%lf %lf %lf \n",cellsX[i],cellsY[i],forceFact);
                    //MODIFIED VERSION 1: TAKE INTERACTING CELLS' RADII INTO CONSIDERATION
//                    pdist = sqrt(pdistX*pdistX + pdistY*pdistY) - 0.7*(cellRadii[counter1]+cellRadii[counter2]);
//                    if (pdist<0.001) pdist=0.001;
//                    pdist2 = pdist*pdist;
//                    invPdist2 = 1/pdist2;
//                    forceFact = 0.2*pow(invPdist2,3) * (pow(invPdist2,3)-1);
                    
                    //MODIFIED VERSION 2: INTERACTION FORCE FORM LJ POTENTIAL
                    pdist = sqrt(pdistX*pdistX + pdistY*pdistY);
                    if (pdist<0.001) pdist=0.001;
                    pdist2 = pdist*pdist;
                    length_scale = cell_mem_rigidity*(cellRadii[counter1]+cellRadii[counter2]);
                    forceFact = forceFact_fun(energy_scale, length_scale, pdist2);

                    //invPdist2 = 1/pdist2;
                    //forceFact = pow(invPdist2,4) * (pow(invPdist2,3)-0.5);
                    //Calculate the action and reaction for the two particles
                    
                    forcesX[counter1] = forcesX[counter1] + pdistX * forceFact;
                    forcesY[counter1] = forcesY[counter1] + pdistY * forceFact;
                    forcesX[counter2] = forcesX[counter2] - pdistX * forceFact;
                    forcesY[counter2] = forcesY[counter2] - pdistY * forceFact;
                }
                
                
//                for (counter2 = 0; counter2 < numVesselcells; counter2++) {
//                    //Calculate particle-particle distance
//                    pdistX = cellsX[counter1] - VesselcellsX[counter2];
//                    pdistY = cellsY[counter1] - VesselcellsY[counter2];
//
//                    //Calculate distance squared
//                    pdist2 = pdistX*pdistX + pdistY*pdistY;
//
//                    //Calculate Lennard-Jones potential assuming sigma=1 and epsilon=1
//                    //See http://www.cchem.berkeley.edu/chem195/_l_j___force_8m.html#af8855bc03346959adac398ca74c45a06
//                    //for details.
//                    invPdist2 = 1/pdist2;
//                    forceFact = pow(invPdist2,4) * (pow(invPdist2,3)-0.5);
//
//                    //Calculate the action and reaction for the two particles
//                    forcesX[counter1] = forcesX[counter1] + 2*pdistX * forceFact;
//                    forcesY[counter1] = forcesY[counter1] + 2*pdistY * forceFact;
//                }
            }

            //Update cell coordinates
//            double max_pos_x = -1.0; // shouldn't reset because tumor is not shrinking
//            double max_pos_y = -1.0;
//            double max_neg_x = 1.0;
//            double max_neg_y = 1.0;
            for (counter1 = 0; counter1 < numCells; counter1++) {
                if (forcesX[counter1] > .2) forcesX[counter1] = .2;
                else if (forcesX[counter1] < -.2) forcesX[counter1] = -.2;
                if (forcesY[counter1] > .2) forcesY[counter1] = .2;
                else if (forcesY[counter1] < -.2) forcesY[counter1] = -.2;
                cellsX[counter1] = cellsX[counter1]  + 0.5*dt2* 48 *forcesX[counter1];
                cellsY[counter1] = cellsY[counter1]  + 0.5*dt2* 48 *forcesY[counter1];
                //printf("%lf %lf %lf %lf %d \n",cellsX[counter1],cellsY[counter1],forcesX[counter1],forcesY[counter1],T);
                
                /**NEW FEATURE: INCLUDE RANDOM BROWNIAN MOTIONS OF CELLS**/
                cellsX[counter1] = cellsX[counter1]  + 0.5*dt2* 48 *BM_scale_pretreat* dose_speed_fact*(-1+2*randZerotoOne());
                cellsY[counter1] = cellsY[counter1]  + 0.5*dt2* 48 *BM_scale_pretreat* dose_speed_fact*(-1+2*randZerotoOne());
                
                forcesX[counter1] = 0;
                forcesY[counter1] = 0;
                cellDist[counter1] = sqrt((cellsX[counter1]-tumor_cen_x)*(cellsX[counter1]-tumor_cen_x) + (cellsY[counter1]-tumor_cen_y)*(cellsY[counter1]-tumor_cen_y));
                
//                /**NEW FEATURE: KEEP TRACK OF MAX. POSITIVE AND NEGATIVE X,Y COORDINATES**/
//                if (cellsX[counter1]>0 && cellsX[counter1]>max_pos_x){
//                    max_pos_x = cellsX[counter1];
//                }
//                if (cellsX[counter1]<0 && cellsX[counter1]<max_neg_x){
//                    max_neg_x = cellsX[counter1];
//                }
//                if (cellsY[counter1]>0 && cellsY[counter1]>max_pos_y){
//                    max_pos_y = cellsY[counter1];
//                }
//                if (cellsY[counter1]<0 && cellsY[counter1]<max_neg_y){
//                    max_neg_y = cellsY[counter1];
//                }
            }

            /*****Handle Aging******/
            for (i=0; i < numCells; i++) {
                if (cellQ[i] == 0)  {
                    cellDivTime[i] = cellDivTime[i] - 1;
                    cellDeathTime[i] = cellDeathTime[i] - 1;
                }
            }
        }//end pre-treatment loop
        
//        for (i=0; i < numCells; i++) {
//            if (cellDist[i] < (Rvessel + RvesselCells + tau * R)) cellType[i] = 1;
//        }
        
        /**NEW FEATURE: LOCATE THE CENTER OF TUMOR AND SET MAXIMUM IR RADIUS**/
        // COUNT CELLS AND OUTPUT PRETREATMENT CELL POSITIONS AND RADII
        stemCount[T] = 0;
        tbCount[T] = 0;
        // RESET MAX POS/NEG X,Y COORDINATES
        max_pos_x = -1.0;
        max_pos_y = -1.0;
        max_neg_x = 1.0;
        max_neg_y = 1.0;
        for (i=0; i < numCells; i++) {
            tbCount[T] = tbCount[T] + 1;
            cellsX_preTreat[i] = cellsX[i];
            cellsY_preTreat[i] = cellsY[i];
            cellRadii_preTreat[i] = cellRadii[i];
            
            if (cellsX[i]>0 && cellsX[i]>max_pos_x){
                max_pos_x = cellsX[i];
            }
            if (cellsX[i]<0 && cellsX[i]<max_neg_x){
                max_neg_x = cellsX[i];
            }
            if (cellsY[i]>0 && cellsY[i]>max_pos_y){
                max_pos_y = cellsY[i];
            }
            if (cellsY[i]<0 && cellsY[i]<max_neg_y){
                max_neg_y = cellsY[i];
            }
        }
        
        tumor_cen_x = 0.5*(max_pos_x + max_neg_x);
        tumor_cen_y = 0.5*(max_pos_y + max_neg_y);
        // FIND MAXIMUM TUMOR RADIUS
        tumor_radius = -1; //reset tumor radius
        for (i=0; i < numCells; i++) {
            // technically this var should be cellDist2TumCen
            cellDist2RadCen = sqrt((cellsX[i]-tumor_cen_x)*(cellsX[i]-tumor_cen_x)+(cellsY[i]-tumor_cen_y)*(cellsY[i]-tumor_cen_y));
            if (cellDist2RadCen > tumor_radius){
                tumor_radius = cellDist2RadCen;
            }
        }
        //printf("tumor_cen_x=%lf, tumor_cen_y=%lf, tumor_radius=%lf, numCells=%d\n",tumor_cen_x,tumor_cen_y,tumor_radius,numCells);
        //printf("pos_x=%lf, neg_x=%lf, pos_y=%lf, neg_y=%lf\n",max_pos_x,max_neg_x,max_pos_y,max_neg_y);
        // SET MAXIMUM IR RADIUS
        //max_IR_radius = max_IR_tumor_ratio*tumor_radius;
        //IR_radius = IR_tumor_ratio*tumor_radius;
        //printf("%lf, %lf, %lf",tumor_cen_x,tumor_cen_y,tumor_radius,max_IR_radius);
        
        preTreat_numCells[0] = numCells;
        printf("Pre-treatment simulation completed (%d cells).\n",numCells);
        
//        int counter = tbCount[T];
//        int count2 = 0;
//        int tTB = numCells - ceil( (double) numCells / ratioTbtoS );
//        for (i=0; i< numCells; i++) {
//            if ((counter < tTB)  && (cellDist[i] > 8))
//            {
//                if (cellType[i] == 0) counter++;
//                cellType[i] = 0;
//            }
//        }
//        stemCount[T] = 0;
//        tbCount[T] = 0;

//        for (i=0; i < numCells; i++) {
//            if (cellType[i] == 0) {
//                stemCount[T] = stemCount[T] + 1;
//            }
//            else {
//                tbCount[T] = tbCount[T] + 1;
//            }
//        }
        
        
        if (rand_treatment == 1) srand(job_id*time(NULL));
        //printf("time = %ld\n",job_id*time(NULL));
        
        //ASIGN CELL DIV. AND DEATH TIMES
        int ave_death, ave_div;
        ave_death = 0;
        ave_div = 0;
        for (i=0; i< numCells; i++) {
            cellDeathTime[i] = (int) floor(randZerotoOne() * (randomDeathProb));
//            cellDivTime[i] = (int) floor(randZerotoOne() * (lambda));
            cellDivTime[i] = (int) floor(randZerotoOne() * (lambda));
            cellAge[i] = cellDeathTime[i];
            ave_death += cellDeathTime[i];
            ave_div += cellDivTime[i];
        }
        
        int RAD_COUNT = 0;
        /**START TREATMENT**/
        for (T=1; T < maxTimeSteps; T++) {
            //            stemCount[T] = 0;
            //            tbCount[T] = 0;
            //            for (i=0; i < numCells; i++) {
            ////                if (cellType[i] == 0) {
            ////                    stemCount[T] = stemCount[T] + 1;
            ////                }
            //                    tbCount[T] = tbCount[T] + 1;
            //            }
            
            // Keep Track of what week, day, time it is after therapy commences
            minute = minute + 1;
            if (minute >= 60*DT) {
                hour = hour + 1;
                minute = 0;
            }
            if (hour >= 24) {
                day = day + 1;
                hour = 0;
            }
            if (day >= 7) {
                week = week + 1;
                day = 0;
                //day = 7;
            }
            
            if (cellGrowth_treat == 1){
                daughterCellSize = 0.5;
            }
            else {
                daughterCellSize = 1;
            }
            
            /**NEW FEATURE: DOSE-DEPENDENT BROWNIAN MOTIONS **/
            //            // RESET dose-speed_factor AFTER 24 HOURS
            //            if (T >= curr_rad_time + (DT*60*24)){
            //                dose_speed_fact = 1.0;
            //            }
            //
            /**NEW FEATURE: RADIATION EFFECT EXPIRES IN 24 HOURS  **/
            for (i=0; i<radNum; i++) {
                if (T == doseExpTime[i]-1){
                    // radiation's effect on cell speed expires
                    dose_speed_fact = dose_speed_fact -incdSpeed[i];
                    // reset diminishing effect factor of radiation on cell speed
                    if (dimEffectYN[i] == 1){
                        dimEffect = dimEffect*2;
                        //printf("dimEffect = %.2lf\n",dimEffect);
                    }
                }
            }
            
            /**Handle Cell Death and Escape**/
            int numKillCells = 0;
            int * cellsToKill;
            double t1,t2;
            cellsToKill = (int *) malloc(sizeof(int)*50000);
            escCount[T] = 0;
            
            for (i=0; i< numCells; i++)
            {
                if (cellState[i] != 1){ //ASSIGN NORMAL AND QUIESC CELLS A DEATH TIME
                    cellDeathTime[i] = (int) floor(randZerotoOne() * (randomDeathProb));
                }
                /**NEW FEATURE: REMOVE CELLS OUTSIDE OF THE IR REGION**/
                cellDist2RadCen = sqrt((cellsX[i]-rad_cen_x)*(cellsX[i]-rad_cen_x) + (cellsY[i]-rad_cen_y)*(cellsY[i]-rad_cen_y));
                //MOD: ONLY LIVE  AND QUIESCENT CELLS CAN DIE, DEAD CELLS CANNOT AGE AND DIE
                // ALL CELLS OUTSIDE OF IR REGION ARE REMOVED
                if ((cellDeathTime[i] == 0 && cellState[i] != 1)  || (cellDist2RadCen > IR_radius))
                {
                    cellsToKill[numKillCells] = i;
                    numKillCells = numKillCells + 1;
                    TOT_KILL = TOT_KILL + 1;
                }
                // COUNT ESCAPED CELLS
                if (cellDist2RadCen > IR_radius && cellState[i] != 1){
                    // MOD: ONLY MARK NORMAL OR QUIESC CELLS AS ESCAPED
                    // ESCAPED DEAD CELLS DON'T COUNT
                    escCount[T] = escCount[T]+1;
                }
            }
            
            
            if (numKillCells > 0) {
                for (i=0; i<numKillCells; i++) {
                    for (j=cellsToKill[i]; j<numCells-i-1; j++) {
                        cellsX[j] = cellsX[1+j];
                        cellsY[j] = cellsY[1+j];
                        cellDivTime[j] = cellDivTime[1+j];
                        cellConc[j] = cellConc[1+j];
                        cellDeathTime[j] = cellDeathTime[1+j];
                        cellDist[j] = cellDist[1+j];
                        cellAge[j] = cellAge[1+j];
                        cellDivRate[j] = cellDivRate[1+j];
                        cellQ[j] = cellQ[1+j];
                        radQ[j] = radQ[1+j];
                        radQt[j] = radQt[1+j];
                        cellRadii[j] = cellRadii[1+j];
                        //CELL STATE
                        cellState[j] = cellState[1+j];
                    }
                    cellsX[numCells] = 0;
                    cellsY[numCells] = 0;
                    cellDeathTime[numCells] = -1;
                    cellConc[numCells] = 0;
                    cellDivRate[numCells] = 0;
                    cellDist[numCells] = 0;
                    cellAge[numCells] = -1;
                    cellQ[numCells] = 0;
                    cellRadii[numCells] = 0;
                    radQ[numCells] = 0;
                    radQt[numCells] = 0;
                    //CELL STATE
                    cellState[numCells] = 0;
                    numCells = numCells -1;
                }
            }
            free(cellsToKill);
            
            /*****Handle Cell Division******/
            for (i=0; i < numCells; i++) {
                if (cellGrowth_treat ==1){
                    if (cellRadii[i] < R*.1) cellDivTime[i] = (int) floor( randZerotoOne() * (lambda));
                }
                else {//no cell size growth
                    cellDivTime[i] = (int) floor( randZerotoOne() * (lambda));
                }
                
                
                if (cellDivTime[i] == 0 && cellState[i] != 1) //MOD: IF CELL'S DIV TIME IS UP AND CELLS NOT DEAD
                {
                    if (cellQ[i] == 0) //MOD from cellQ[i] == 0: ONLY NORMAL CELLS CAN DIVIDE
                    {
                        TOT_DIV = TOT_DIV + 1;
                        cellRadii[numCells] = daughterCellSize*cellRadii[i];
                        cellRadii[i] = cellRadii[i] *daughterCellSize;
                        double rtmp = randZerotoOne();
                        if (rtmp < .25) { //put horizontal
                            cellsX[numCells] = cellsX[i] + cellRadii[i];
                            cellsY[numCells] = cellsY[i];
                            cellsX[i] = cellsX[i] - cellRadii[i];
                        }
                        else if (rtmp < 0.5) { //put vertical
                            cellsY[numCells] = cellsY[i] + cellRadii[i];
                            cellsX[numCells] = cellsX[i];
                            cellsY[i] = cellsY[i] - cellRadii[i];
                        }
                        else if (rtmp < 0.75) { //diagonal
                            double h1 = sqrt(cellRadii[i] * cellRadii[i]*daughterCellSize);
                            cellsX[numCells] = cellsX[i] + h1;
                            cellsX[i] = cellsX[i] -h1 ;
                            cellsY[numCells] = cellsY[i]+h1;
                            cellsY[i] = cellsY[i] -h1;
                        }
                        else {
                            double h1 = sqrt(cellRadii[i] * cellRadii[i]*daughterCellSize);
                            cellsX[numCells] = cellsX[i] - h1;
                            cellsX[i] = cellsX[i] + h1 ;
                            cellsY[numCells] = cellsY[i]+h1;
                            cellsY[i] = cellsY[i] - h1;
                        }
                        cellDivRate[i] = (1/rTB)*DT*60;
                        cellDist[i] = sqrt((cellsX[i]-tumor_cen_x)*(cellsX[i]-tumor_cen_x) + (cellsY[i]-tumor_cen_y)*(cellsY[i]-tumor_cen_y));
                        cellDist[numCells] = sqrt((cellsX[numCells]-tumor_cen_x)*(cellsX[numCells]-tumor_cen_x) + (cellsY[numCells]-tumor_cen_y)*(cellsY[numCells]-tumor_cen_y));
                        cellDivRate[numCells] = cellDivRate[i];
                        //cellDivTime[i] = (int) floor( randZerotoOne() * lambda);
                        cellDivTime[i] = (int) floor(lognormal_rand(lambda,lambda_var));
                        cellConc[numCells] = cellConc[i];
                        //cellDivTime[numCells] = (int) floor( randZerotoOne() * lambda);
                        cellDivTime[numCells] = (int) floor(lognormal_rand(lambda,lambda_var));
                        //NO DEATH FOR NOW
                        cellDeathTime[i] = (int) floor( randZerotoOne() * (randomDeathProb));
                        cellDeathTime[numCells] = (int) floor( randZerotoOne() * (randomDeathProb));
                        cellAge[i] = cellDeathTime[i];
                        cellAge[numCells] = cellDeathTime[numCells];
                        cellQ[i] = 0;
                        cellQ[numCells] = 0;
                        radQ[i] = 0;
                        radQ[numCells] = 0;
                        radQt[i] = 0;
                        radQt[numCells] = 0;
                        // UPDATE CELL STATES OF THE TWO DAUGHTER CELLS
                        cellState[i] = 0;
                        cellState[numCells] = 0;
                        numCells = numCells + 1;
                    }
                }
            }
            /**HANDLE CELL GROWTH**/
            if (cellGrowth_treat == 1){
                for (i=0; i < numCells; i++) {
                    if (cellRadii[i] <= R*1.25 && cellState[i] == 0) {
                        //MOD: ONLY NORMAL CELLS CAN GROW
                        cellRadii[i] = cellRadii[i] * growth;
                    }
                }
            }
            /*****Calculate Force on cell and move glial cells appropriately******/
            double forceFact,invPdist2, pdistX,pdistY,pdist2, pdist1;

            for (counter1 = 0; counter1 < numCells -1; counter1++) {
                for (counter2 = counter1+1; counter2 < numCells; counter2++) {
                    //Calculate particle-particle distance
                    pdistX = cellsX[counter1] - cellsX[counter2];
                    pdistY = cellsY[counter1] - cellsY[counter2];

//                    //Calculate distance squared
//                    pdist2 = pdistX*pdistX + pdistY*pdistY;
//
//                    //Calculate Lennard-Jones potential assuming sigma=1 and epsilon=1
//                    //See http://www.cchem.berkeley.edu/chem195/_l_j___force_8m.html#af8855bc03346959adac398ca74c45a06
//                    //for details.
//                    invPdist2 = 1/pdist2;
//                    forceFact = pow(invPdist2,4) * (pow(invPdist2,3)-0.5);
                    
                    //MODIFIED VERSION 2: INTERACTION FORCE FORM LJ POTENTIAL
                    pdist = sqrt(pdistX*pdistX + pdistY*pdistY);
                    if (pdist<0.001) pdist=0.001;
                    pdist2 = pdist*pdist;
                    length_scale = cell_mem_rigidity*(cellRadii[counter1]+cellRadii[counter2]);
                    forceFact = forceFact_fun(energy_scale, length_scale, pdist2);

                    //Calculate the action and reaction for the two particles
                    forcesX[counter1] = forcesX[counter1] + pdistX * forceFact;
                    forcesY[counter1] = forcesY[counter1] + pdistY * forceFact;
                    forcesX[counter2] = forcesX[counter2] - pdistX * forceFact;
                    forcesY[counter2] = forcesY[counter2] - pdistY * forceFact;
                }
            }

            //Update cell coordinates
            tumor_radius = -1; // reset tumor radius
            max_pos_x = -1.0;
            max_pos_y = -1.0;
            max_neg_x = 1.0;
            max_neg_y = 1.0;
            for (counter1 = 0; counter1 < numCells; counter1++) {
                if (forcesX[counter1] > .2) forcesX[counter1] = .2;
                else if (forcesX[counter1] < -.2) forcesX[counter1] = -.2;
                if (forcesY[counter1] > .2) forcesY[counter1] = .2;
                else if (forcesY[counter1] < -.2) forcesY[counter1] = -.2;
                cellsX[counter1] = cellsX[counter1] + 0.5*dt2* 48 *forcesX[counter1];
                cellsY[counter1] = cellsY[counter1]  + 0.5*dt2* 48 *forcesY[counter1];
                
                /**NEW FEATURE: INCLUDE RANDOM BROWNIAN MOTIONS OF CELLS**/
                
                //MOD:
                if (cellState[counter1] == 1){ //MOD: DEAD CELLS MOVE AT BASAL BROWNIAN SPEED
                    cellsX[counter1] = cellsX[counter1]  + 0.5*dt2* 48 *BM_scale_treat*(-1+2*randZerotoOne());
                    cellsY[counter1] = cellsY[counter1]  + 0.5*dt2* 48 *BM_scale_treat*(-1+2*randZerotoOne());
                }
                else {//MOD: NORMAL AND QUIESC CELLS MOVE AT DOSE-DEPENDENT BROWNIAN SPEED
                    cellsX[counter1] = cellsX[counter1]  + 0.5*dt2* 48 *BM_scale_treat* dose_speed_fact*(-1+2*randZerotoOne());
                    cellsY[counter1] = cellsY[counter1]  + 0.5*dt2* 48 *BM_scale_treat* dose_speed_fact*(-1+2*randZerotoOne());
                }
                
                forcesX[counter1] = 0;
                forcesY[counter1] = 0;
                //cellDist[counter1] = sqrt(cellsX[counter1]*cellsX[counter1] + cellsY[counter1] * cellsY[counter1]);
                
                /**NEW FEATURE: KEEP TRACK OF MAX. POSITIVE AND NEGATIVE X,Y COORDINATES**/
                if (cellsX[counter1]>0 && cellsX[counter1]>max_pos_x){
                    max_pos_x = cellsX[counter1];
                }
                if (cellsX[counter1]<0 && cellsX[counter1]<max_neg_x){
                    max_neg_x = cellsX[counter1];
                }
                if (cellsY[counter1]>0 && cellsY[counter1]>max_pos_y){
                    max_pos_y = cellsY[counter1];
                }
                if (cellsY[counter1]<0 && cellsY[counter1]<max_neg_y){
                    max_neg_y = cellsY[counter1];
                }
                tumor_cen_x = 0.5*(max_pos_x+max_neg_x);
                tumor_cen_y = 0.5*(max_pos_y+max_neg_y);
                //THIS IS THE ONLY PLACE WHERE WE UPDATE CELL DISTANCE cellDist
                cellDist[counter1] = sqrt((cellsX[counter1]-tumor_cen_x)*(cellsX[counter1]-tumor_cen_x) + (cellsY[counter1]-tumor_cen_y)*(cellsY[counter1]-tumor_cen_y));
                //printf("%lf  %lf  %lf  %lf\n",tumor_cen_x, tumor_cen_y,tumor_radius, cellDist[counter1]);
                // UPDATE TUMOR RADIUS
                if (cellDist[counter1] > tumor_radius){
                    tumor_radius = cellDist[counter1];
                }
            }
            //printf("tumor_center=(%.2lf,%.2lf)\n", tumor_cen_x,tumor_cen_y);
            
            /*****Handle Radiotherapy******/
            giveRad=0; //reset radiation flag
            cellsToKill = (int *) malloc(sizeof(int)*70000);
            numKillCells = 0;
            
            
            // week, day, hour,
            if (week < RadWeeks){
                day_adjusted = day + week*7;
                if (day_adjusted == radDay[RAD_COUNT]){
                    if (hour == radHour[RAD_COUNT]) {
                        if (minute == 8){
                            radDose = radDoseA[RAD_COUNT];
                            if (radDose > 0) {
                                giveRad = 1;
                                RAD_COUNT = RAD_COUNT +1;
                                /**NEW FEATURE: TUMOR-VOLUME DEPENDENT IR REGION AND DOSE-DEPENDENT BROWNIAN MOTIONS **/
                                if (RAD_COUNT ==1){ //FIRST DOSE:
                                    //SET IR RADIUS AND FIX IT THROUGH OUT TREATMENT
                                    if (fixRadRegion == 1){
                                        IR_radius = IR_tumor_ratio*tumor_radius;
//                                        rad_cen_x = tumor_cen_x;
//                                        rad_cen_y = tumor_cen_y;
                                        //printf("Set fixed IR region:\n");
                                    }

                                }
                                if (fixRadRegion == 0){
                                    IR_radius = IR_tumor_ratio*tumor_radius;
                                }
//                                  if (IR_radius > max_IR_radius){
//                                       IR_radius = max_IR_radius;
//                                  }
                                 rad_cen_x = tumor_cen_x;
                                 rad_cen_y = tumor_cen_y;
                                 //printf("IR_radius=%.2lf, IR_center=(%.2lf,%.2lf)\n",IR_radius,rad_cen_x,rad_cen_y);
                                
                                //printf("day=%d, hour=%d, min=%d, dose=%d\n",day,hour,minute,radDose);
                                // CHECK IF THE LAST RADIATION IS WITHIN 24 HOURS
                                if (T-curr_rad_time <  DT*60*24 & T-curr_rad_time >0 ){
                                    //RADIATION EFFECT ON CELL SPEED DIMINISHES
                                    dimEffect = dimEffect*.5;
                                    dimEffectYN[radNum] = 1;
                                }
                                else{
                                    dimEffectYN[radNum] = 0;
                                }
                                // DOSE-DEPENDENET CELL SPEED
                                dose_speed_fact = dose_speed_fact+dose_speed_corr*dimEffect*radDose;
                                //printf("dose-speed-fact_after=%.2lf, dimEffect=%.2lf,  dose_speed_corr=%.2lf\n",dose_speed_fact,dimEffect,dose_speed_corr);
                                curr_rad_time = T;
                                doseExpTime[radNum] = T+(DT*60*24); //dose effect on cell speed expires in 24 hrs;
                                incdSpeed[radNum] = dose_speed_corr*dimEffect*radDose;
                                //printf("week=%d,day=%d, hour=%d, min=%d, dose=%d, dose-speed_fact=%.2lf\n",week,day_adjusted,hour,minute,radDose, dose_speed_fact);
                                radNum = radNum +1;
                            }
                        }
                    }
                    
                }
            }
            
            
            
//            if (week < RadWeeks) {
//                day_adjusted = day + week*7;
//                //printf("day=%d, day_adjusted=%d\n",day,day_adjusted);
//                for (i=0; i< radDoses; i++) {
//                    //printf("i=%d, week=%d\n",i,week);
//                    //printf("day=%d, radDay[i]=%d\n",day,radDay[i]);
//                    if (day_adjusted == radDay[i]) {
//                        if (hour == radHour[i]) {
//                            if (minute == 8) {
//                                radDose = radDoseA[i];
//                                if (radDose > 0) {
//                                    giveRad = 1;
//                                    printf("day=%d, day_adjusted=%d, T=%d\n",day,day_adjusted,T);
//                                    /**NEW FEATURE: TUMOR-VOLUME DEPENDENT IR REGION AND DOSE-DEPENDENT BROWNIAN MOTIONS **/
//                                    if (i==0 & week==0){ //FIRST DOSE:
//                                        //SET IR RADIUS AND FIX IT THROUGH OUT TREATMENT
//                                        IR_radius = IR_tumor_ratio*tumor_radius;
////                                        rad_cen_x = tumor_cen_x;
////                                        rad_cen_y = tumor_cen_y;
//                                        printf("Set fixed IR region:\n");
//                                        //printf("IR_radius=%.2lf, IR_center=(%.2lf,%.2lf)\n",IR_radius,rad_cen_x,rad_cen_y);
//                                    }
//  
//                                    //IR_radius = IR_tumor_ratio*tumor_radius;
////                                    if (IR_radius > max_IR_radius){
////                                        IR_radius = max_IR_radius;
////                                    }
//                                     rad_cen_x = tumor_cen_x;
//                                     rad_cen_y = tumor_cen_y;
//                                    //printf("day=%d, hour=%d, min=%d, dose=%d\n",day,hour,minute,radDose);
//                                    // CHECK IF THE LAST RADIATION IS WITHIN 24 HOURS
//                                    if (T-curr_rad_time <  DT*60*24 & T-curr_rad_time >0 ){
//                                        //RADIATION EFFECT ON CELL SPEED DIMINISHES
//                                        dimEffect = dimEffect*.5;
//                                        dimEffectYN[radNum] = 1;
//                                    }
//                                    else{
//                                        dimEffectYN[radNum] = 0;
//                                    }
//                                    // DOSE-DEPENDENET CELL SPEED
//                                    dose_speed_fact = dose_speed_fact+dose_speed_corr*radDose;
//                                    //dose_speed_fact = dose_speed_fact+dose_speed_corr*dimEffect*radDose;
//                                    //printf("dose-speed-fact_after=%.2lf, dimEffect=%.2lf,  dose_speed_corr=%.2lf\n",dose_speed_fact,dimEffect,dose_speed_corr);
//                                    curr_rad_time = T;
//                                    doseExpTime[radNum] = T+(DT*60*24); //dose effect on cell speed expires in 24 hrs;
//                                    incdSpeed[radNum] = dose_speed_corr*dimEffect*radDose;
//                                    printf("week=%d,day=%d, hour=%d, min=%d, dose=%d, dose-speed_fact=%.2lf\n",week,day_adjusted,hour,minute,radDose, dose_speed_fact);
//                                    radNum = radNum +1;
//                                    //printf("IR_radius=%.2lf, IR_center=(%.2lf,%.2lf), numCells=%d\n",IR_radius,rad_cen_x,rad_cen_y,numCells);
//                                    //printf("numCells=%d, tumor radius=%lf, IR radius=%lf, dose-speed fact=%lf\n",numCells,tumor_radius,IR_radius,dose_speed_fact);
//                                }
//                            }
//                        }
//                    }
//                }
//            }
            
            double tmp5;
            if (giveRad == 1) {
                TOT_RAD = TOT_RAD + 1;
                //MOD: ALL NON-DEAD CELLS ENTER QUIESCENCE
                //numKillCells=0; //<-- NO CELLS "DIE"
                for (i=0; i < numCells; i++) {
                    //if (Quiescence == 1){
                        if (cellState[i] != 1 ) { // MOD: IF CELLS ARE NOT DEAD
                            
                            radQ[i] = DT*60*LTumorBulk + (int) floor(randZerotoOne() * (1/lambdaTumorBulk) *DT*2);
                            radQt[i] = 1;
                        }
                    //}
                    alpha = alphaT;
                    beta = betaT;
            
                    //tmp5 = sens*cellConc[i];
                    //if (tmp5 > 0) tmp5 = tmp5/(.00005);
                    //else tmp5 = 0;
                    //if (cellState[i] != 1) {// MOD: ALL QUIESCENT CELLS SUBJECT TO LQ RAD RESPONSE
                    //printf("rand = %.2lf,alpha = %.2lf,beta = %.2lf,rho = %.2lf,radDose = %d\n", randZerotoOne(),alpha,beta,rho,radDose);
                    if (cellState[i] != 1){
                    if (randZerotoOne() <= 1-exp(-1*alpha*rho*radDose-beta*rho*radDose*radDose)) {
                            //printf("Cells dead\n");
                            //cellsToKill[numKillCells] = i;
                            //numKillCells = numKillCells + 1;
                            //cellType[i] = 3;
                            cellState[i] = 1; // NO CELLS ARE REMOVED, INSTEAD THEIR CELL STATE IS SET TO 1
                            RAD_KILL=RAD_KILL+1;
                    }
                    }
//                    else {
//                        if (timeDepGamma == 1) gamma = .4 * exponential(10,-1*(T-mu)*(T-mu)/(sigmaS));
//                        celldeDiffTime[i] = -1;
//                        if (randZerotoOne() <= gamma) {
//                            if (cellQ[i] == 0) {
//                                if (cellType[i] < Zrevert) {
//                                    cellType[i] = cellType[i] -1;
//                                    celldeDiffTime[i] = (int) floor(randZerotoOne() * (randomDediff));
//                                    if (cellType[i] < 0) cellType[i] = 0;
//                                }
//                            }
//                        }
//                    }
                }
            }

//            if (numKillCells > 0) {
//                for (i=0; i<numKillCells; i++) {
//                    for (j=cellsToKill[i]; j<numCells-i-1; j++) {
//                        cellsX[j] = cellsX[1+j];
//                        cellsY[j] = cellsY[1+j];
//                        cellDivTime[j] = cellDivTime[1+j];
//                        cellConc[j] = cellConc[1+j];
//                        cellDeathTime[j] = cellDeathTime[1+j];
//                        cellDist[j] = cellDist[1+j];
//                        cellAge[j] = cellAge[1+j];
//                        cellDivRate[j] = cellDivRate[1+j];
//                        cellQ[j] = cellQ[1+j];
//                        radQ[j] = radQ[1+j];
//                        radQt[j] = radQt[1+j];
//                        cellRadii[j] = cellRadii[1+j];
//                    }
//                    cellsX[numCells] = 0;
//                    cellsY[numCells] = 0;
//                    cellDeathTime[numCells] = -1;
//                    cellDivTime[numCells] = -1;
//                    cellConc[numCells] = 0;
//                    cellDist[numCells] = 0;
//                    cellAge[numCells] = -1;
//                    cellDivRate[numCells] = 0;
//                    cellQ[numCells] = 0;
//                    cellRadii[numCells] = 0;
//                    radQ[numCells] = 0;
//                    radQt[numCells] = 0;
//                    numCells = numCells -1;
//                }
//            }
//
//            free(cellsToKill);
            
            
            /**HANDLE QUIESCENCE**/
            if (Quiescence == 1) {//THEN CELLS CONVERT TO QUIESCENT STATE (cellState = 2)
                for (i=0; i < numCells; i++) {
                    //MOD: ONLY NORMAL OR QUIESCENT CELLS CEN ENTER OR REMAIN QUIESCENCE
                    if (cellState[i] != 1){ //IF CELLS NOT DEAD
                        if (radQ[i] > 0) {
                            radQ[i] = radQ[i] - 1;
                            radQt[i] = radQt[i] + 1;
                            cellQ[i] = 1;
                            cellState[i] =2; //MOD: UPDATE CELL STATE TO QUIESCENCE
                            if (radQ[i] ==0) { //exit quiescience
                                cellDivRate[i] = (1/rTB)*DT*60;
                                cellDivRate[numCells] = cellDivRate[i];
                                //DO NO RESET DIVISION TIME FOR CELLS EXITING QUIESCENCE
                                //cellDivTime[i] = (int) floor( randZerotoOne() * (lambda));
                                //cellDivTime[numCells] = (int) floor( randZerotoOne() * (lambda));
                            }
                        } else {
                            radQt[i] = 0;
                            cellQ[i] = 0;
                            cellState[i] = 0; //MOD: CELL REVERTS TO NORMAL STATE
                        }
                    }
                }
            }
            
            
            /*****Handle Aging******/
            for (i=0; i < numCells; i++) {
                //ONLY NORMAL CELLS CAN AGE
                if (cellState[i] == 0)  {
                    cellDivTime[i] = cellDivTime[i] - 1;
                    cellDeathTime[i] = cellDeathTime[i] - 1;
                    //MOD:
                    
                }
            }

            /*****Count Cell Type******/
            //stemCount[T] = 0;
            tbCount[T] = 0;
            for (i=0; i < numCells; i++) {
                if (cellState[i] != 1){//MOD: IF CELLS NOT DEAD
                    tbCount[T] = tbCount[T] + 1;
                }
            }
            // STORE TUMOR RADIUS AND TUMOR DENSITY;
            tumorMaxRadii[T] =tumor_radius;
            tumorDensities[T] = (numCells)/(3.1416*tumor_radius*tumor_radius); //numCells/(pi*(tumor_radius)^2)
            
        }//end treatment loop (1:maxTimeSteps)
        //printf("final time point = %d\n", T);
        
        // PASS OUTPUT VALUES
//        *postTreat_numCells = numCells;
//        *rad_cen_x_out = rad_cen_x;
//        *rad_cen_y_out = rad_cen_y;
//        *IR_radius_out = IR_radius;
        
        //TEST
        postTreat_numCells[0] = numCells;
        rad_cen_x_out[0] = rad_cen_x;
        rad_cen_y_out[0] = rad_cen_y;
        IR_radius_out[0] = IR_radius;
        
        //printf("Post-treatment simulation completed.\n");
        
        //printf("numCells_out = %d\n", *numCells_out);
    }//end cycle
}//end function


