/*Copyright (c) 2018, Dana Farber Cancer Institute, Duke University
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:
    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in the
      documentation and/or other materials provided with the distribution.
    * Neither the name of the DFCI or Duke nor the
      names of its contributors may be used to endorse or promote products
      derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL DANA FARBER CANCER INSTITUTE OR DUKE UNIVERSITY
BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NO T LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.*/

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include "math.h"
#include "time.h"
#include "cellMobilityModelLoop.h"


//declaring function cellModelLoop
void cellMobilityModelLoop(int maxTimeSteps, double sens, int Z, int Zrevert, int RadWeeks, int radDoses, int radDoseA[100], int radHour[100], int radDay[100], int *stemCount, int * tbCount, int * escCount, int *cellAge, double * cellsX, double * cellsY, double * cellRadii, double * cellsX_preTreat,double * cellsY_preTreat,double * cellRadii_preTreat, int* preTreat_numCells, int* postTreat_numCells, double * tumorDensities,double * tumorMaxRadii, double* rad_cen_x_out, double* rad_cen_y_out, double* IR_radius_out, int * cellState, int job_id);


//Note: Run this with passing in the fileName for the schedule
int main(int argc, char** argv) {
    

    /****************** Open Input File ******************************/
    FILE *fp,*fpsched,*fout1,*fout2,*fout3, *fout4;
    fp =fopen(argv[1],"r");  //open file that was passed in as argv[1]®
    if (fp==NULL){      //error checking
        printf("Error! opening input file.\n");
        exit(1);
    }
    
    /****************** Open Output File ******************************/
    
    
    char folder_name[256] = "outputs_"; //name of folder where oputput csv files are stored
    int job_id = atoi(argv[2]); //read job id
    printf("Job ID = %d\n",job_id);
    char id_str[10]; //create a string var for job id
    sprintf(id_str,"%d",job_id);
    strcat(folder_name,id_str); //folder_name = outputs_{job_id}
    
    char fout1_path[256];
    char fout2_path[256];
    char fout3_path[256];
    char fout4_path[256];
    strcpy(fout1_path, folder_name);
    strcpy(fout2_path, folder_name);
    strcpy(fout3_path, folder_name);
    strcpy(fout4_path, folder_name);
    
    strcat(fout1_path,"/output_time_series.csv");
    strcat(fout2_path,"/pre_treatment_cell_positions.csv");
    strcat(fout3_path,"/post_treatment_cell_positions.csv");
    strcat(fout4_path,"/output_values.csv");
    
    printf("%s\n", fout1_path);
    printf("%s\n", fout2_path);
    printf("%s\n", fout3_path);
    printf("%s\n", fout4_path);
   
    fout1 =fopen(fout1_path,"w");  //open file that was passed in as argv[1]
    if (fp==NULL){      //error checking
        printf("Error! opening input file.\n");
        exit(1);
    }
    
    fout2 =fopen(fout2_path,"w");  //open file that was passed in as argv[1]
    if (fp==NULL){      //error checking
        printf("Error! opening input file.\n");
        exit(1);
    }

    fout3 =fopen(fout3_path,"w");  //open file that was passed in as argv[1]
    if (fp==NULL){      //error checking
        printf("Error! opening input file");
        exit(1);
    }
    
    fout4 =fopen(fout4_path,"w");  //open file that was passed in as argv[1]
    if (fp==NULL){      //error checking
        printf("Error! opening input file");
        exit(1);
    }

    /*************** Read In Input File Parameters *******************/
    char name[256];
    char * token;
    char fileName[256];
    char outputFileName[256];
    int maxTimeSteps;
    int Z, T;
    double sens;
    int *cellAge;
    int Zrevert;


    fscanf(fp,"%s = %s\n",name,fileName);
    fscanf(fp,"%s = %d\n",name,&maxTimeSteps);
    fscanf(fp,"%s = %d\n",name,&Z);
    fscanf(fp,"%s = %d\n",name,&Zrevert);
    fscanf(fp,"%s = %lf\n",name,&sens);
    fclose(fp); //close input file

    //print input and schedule files being used to stdout
    printf("Input file: %s\n", argv[1]);
    printf("Schedule file: %s\n", fileName);

    /*************** Read In Schedule Parameters *******************/
    fp =fopen(fileName,"r");  //open file that was passed in as the schedule
    if (fp==NULL){      //error checking
        printf("Error! opening schedule file");
        exit(1);
    }
    int RadWeeks;
    int radDoses;
    int radDoseAInput[100];
    int radHourInput[100];
    int radDayInput[100];
//    int radDoseA[50];
//    int radHour[50];
//    int radDay[50];
    int i,j;

    for (i=0; i<100; i++){
        radDoseAInput[i] = 0;
        radHourInput[i] = -1;
        radDayInput[i] = -1;
//        radDoseA[i] = 0;
//        radHour[i] = -1;
//        radDay[i] = -1;
    }
    
    fscanf(fp,"%s = %d\n",name,&RadWeeks);  //start of radation parameters
    fscanf(fp,"%s = %d\n",name,&radDoses);

    for (i=0; i<RadWeeks; i++){
        fscanf(fp,"%s = %d %d %d %d %d %d %d %d %d %d\n",name,&radDoseAInput[i*10+0],&radDoseAInput[i*10+1],&radDoseAInput[i*10+2],&radDoseAInput[i*10+3],&radDoseAInput[i*10+4],&radDoseAInput[i*10+5],&radDoseAInput[i*10+6],&radDoseAInput[i*10+7],&radDoseAInput[i*10+8],&radDoseAInput[i*10+9]);
        fscanf(fp,"%s = %d %d %d %d %d %d %d %d %d %d\n",name,&radHourInput[i*10+0],&radHourInput[i*10+1],&radHourInput[i*10+2],&radHourInput[i*10+3],&radHourInput[i*10+4],&radHourInput[i*10+5],&radHourInput[i*10+6],&radHourInput[i*10+7],&radHourInput[i*10+8],&radHourInput[i*10+9]);
        fscanf(fp,"%s = %d %d %d %d %d %d %d %d %d %d\n",name,&radDayInput[i*10+0],&radDayInput[i*10+1],&radDayInput[i*10+2],&radDayInput[i*10+3],&radDayInput[i*10+4],&radDayInput[i*10+5],&radDayInput[i*10+6],&radDayInput[i*10+7],&radDayInput[i*10+8],&radDayInput[i*10+9]);
    }
    
    
    int radDoseA[RadWeeks*10];
    int radHour[RadWeeks*10];
    int radDay[RadWeeks*10];
    for (i=0; i<RadWeeks*10; i++){
        radDoseA[i] = 0;
        radHour[i] = -1;
        radDay[i] = -1;
    }
    
    
//    for (i=0; i<20; i++){
//        printf("Week %d, Day %d Hour %d: Dose =%d, \n",RadWeeks,radDayInput[i],radHourInput[i],radDoseAInput[i]);
//    }
    int lastRadDay = -1;
    int counter = 0;
    for (i=0; i<RadWeeks; i++){// i = 0,1
        for (j=0; j<10; j++){
            if (radDayInput[i*10+j] >= 0)  {
                radDay[counter] =i*7+radDayInput[i*10+j];
                radHour[counter] =radHourInput[i*10+j];
                radDoseA[counter] =radDoseAInput[i*10+j];
                if (radDay[counter] > lastRadDay){
                    lastRadDay =radDay[counter];
                }
                counter = counter+1;
            }
        }
    }
        //printf("Ajusted schedule: \n");
    for (i=0; i<RadWeeks*10; i++){
        if (radDay[i] >= 0){
            //printf("Day %d Hour %d: Dose =%d, \n",radDay[i],radHour[i],radDoseA[i]);
        }
    }
    
    
//    outputFileName[0] = 0;
//    strcat(outputFileName,"output");
//    strcat(outputFileName + strlen(outputFileName),argv[1]+5);

    
    //MOD: CHANGE maxTimeSteps BASED ON NUMBER OF WEEKS OF RADIATION
    //printf("Last rad treatment occurs on day %d \n",lastRadDay);
    //printf("Simulation stops on day %d \n",lastRadDay+1);
    
    //maxTimeSteps = (2*60*24)*(lastRadDay+2);
    maxTimeSteps =(2*60*24)*(lastRadDay+2);
    //maxTimeSteps = (2*60*24)*(5); //two days
    //printf("maxTimeSteps = %d \n",maxTimeSteps);
    
    
    int *tbCount;
    tbCount = (int *) malloc(sizeof(int)*maxTimeSteps);
    cellAge = (int *) malloc(sizeof(int)*10000);
    int *stemCount; //array to keep track of the number of stem cells over time
    stemCount = (int *) malloc(sizeof(int)*maxTimeSteps);
    
    int *escCount;// escaped celll count
    escCount = (int *) malloc(sizeof(int)*maxTimeSteps);
            
    double *tumorDensities;// numCells/(tumor area)
    double *tumorMaxRadii;// maximum radius of tumor over size
    tumorDensities = (double *) malloc(sizeof(double)*maxTimeSteps);
    tumorMaxRadii = (double *) malloc(sizeof(double)*maxTimeSteps);
    
    //Initialize counts
    for (T=0; T < maxTimeSteps; T++) {
        tbCount[T] = 0;
        stemCount[T] = 0;
        escCount[T] =0;
        tumorDensities[T] =0;
        tumorMaxRadii[T]=0;
        
    }
    
    
    // OUTPUT VALUES (POINTERs)
//    int preTreat_numCells;
//    int postTreat_numCells;
//    double rad_cen_x_out;
//    double rad_cen_y_out;
//    double IR_radius_out;
    
    //TEST
    int *preTreat_numCells;
    int *postTreat_numCells;
    double *rad_cen_x_out;
    double *rad_cen_y_out;
    double *IR_radius_out;
    
    preTreat_numCells = (int *) malloc(sizeof(int)*1);
    postTreat_numCells = (int *) malloc(sizeof(int)*1);
    rad_cen_x_out = (double *) malloc(sizeof(double)*1);
    rad_cen_y_out = (double *) malloc(sizeof(double)*1);
    IR_radius_out = (double *) malloc(sizeof(double)*1);

    double *cellsX;
    double *cellsY;
    double *cellRadii;
    cellsX = (double *) malloc(sizeof(double)*10000);
    cellsY = (double *) malloc(sizeof(double)*10000);
    cellRadii = (double *) malloc(sizeof(double)*10000);
    
    double *cellsX_preTreat;
    double *cellsY_preTreat;
    double *cellRadii_preTreat;
    cellsX_preTreat = (double *) malloc(sizeof(double)*10000);
    cellsY_preTreat = (double *) malloc(sizeof(double)*10000);
    cellRadii_preTreat = (double *) malloc(sizeof(double)*10000);
    
    int *cellState;
    cellState = (int *) malloc(sizeof(int)*10000);

    
//    cellMobilityModelLoop(maxTimeSteps,sens,Z, Zrevert, RadWeeks, radDoses, radDoseA, radHour, radDay, stemCount,tbCount,escCount,cellAge,cellsX,cellsY,cellRadii,cellsX_preTreat,cellsY_preTreat,cellRadii_preTreat, &preTreat_numCells, &postTreat_numCells,tumorDensities,tumorMaxRadii,&rad_cen_x_out, &rad_cen_y_out, &IR_radius_out);
    
    cellMobilityModelLoop(maxTimeSteps,sens,Z, Zrevert, RadWeeks, radDoses, radDoseA, radHour, radDay, stemCount,tbCount,escCount,cellAge,cellsX,cellsY,cellRadii,cellsX_preTreat,cellsY_preTreat,cellRadii_preTreat, preTreat_numCells, postTreat_numCells,tumorDensities,tumorMaxRadii,rad_cen_x_out, rad_cen_y_out, IR_radius_out,cellState,job_id);

//    for (i=2; i < maxTimeSteps; i++) {
//        fprintf(fout,"%d, %d, %d\n", i, (int) floor(tbCount[i]),  (int) floor(stemCount[i]) );
//    }
    for (i=1; i < maxTimeSteps; i++) {
        fprintf(fout1,"%d, %d, %d, %lf, %lf\n", i, (int) floor(tbCount[i]),  (int) floor(escCount[i]), (double ) tumorDensities[i],(double) tumorMaxRadii[i] );
    }
    int total_escCount = 0;
    for (i=1; i < maxTimeSteps; i++) {
        total_escCount = total_escCount +escCount[i];
    }
    
//    printf("pre treatment cell count = %d, post treatment cell count = %d, escaped cell count = %d\n",(int) preTreat_numCells[0],(int) postTreat_numCells[0],total_escCount);
    
    for (i=0; i< preTreat_numCells[0]; i++){
        fprintf(fout2, "%d, %f, %f, %f\n",i,(double) cellsX_preTreat[i], (double) cellsY_preTreat[i], (double) cellRadii_preTreat[i]);
    }
    
    for (i=0; i< postTreat_numCells[0]; i++){
        fprintf(fout3, "%d, %f, %f, %f, %d\n",i,(double) cellsX[i], (double) cellsY[i], (double) cellRadii[i], (int) cellState[i]);
    }
    
    fprintf(fout4, "%d, %d, %f, %f, %f\n",(int) preTreat_numCells[0], (int) postTreat_numCells[0], (double) rad_cen_x_out[0], (double) rad_cen_y_out[0], (double) IR_radius_out[0]);

    
    //printf("numCells_out = %d\n", *numCells_out);
    
    fclose(fout1); //close output file
    fclose(fout2); //close output file
    fclose(fout3); //close output file
    fclose(fout4); //close output file
    free(tbCount);
    free(stemCount);
    free(escCount);
    free(cellsX);
    free(cellsY);
    free(cellRadii);
    free(cellsX_preTreat);
    free(cellsY_preTreat);
    free(cellRadii_preTreat);
    free(tumorDensities);// numCells/(tumor area)
    free(tumorMaxRadii);// maximum radius of tumor over size
    free(preTreat_numCells);
    free(postTreat_numCells);
    free(rad_cen_x_out);
    free(rad_cen_y_out);
    free(IR_radius_out);
    free(cellAge);
    free(cellState);
}





